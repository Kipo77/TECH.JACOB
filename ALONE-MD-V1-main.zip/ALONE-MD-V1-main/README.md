
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <h1 align="center"> A͛L͛O͛N͛E͛ M͛D͛ </h1>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
      
![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗔𝗠+VERY+ALONE+KINDLY+DEPLOY+ME😢)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 
<p align="center"> Introducing ALONE Md, A Simple WhatsApp user BOT, Created by topu Tech.
</p>

  <a href="https://ibb.co/N6NMDtn"><img src="https://files.catbox.moe/v3vzdb.jpg" alt="01" border="0" /></a>                     
<a><img src='https://i.imgur.com/LyHic3i.gif'/>&</a>
 




<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


#### SETUP

1.👇 Star and Fork This Repo  
[![Star and Fork This Repo](https://img.shields.io/static/v1?label=Star%20%26%20Fork%20This%20Repo&message=GitHub&color=181717&style=for-the-badge&logo=github&logoColor=white)](https://github.com/Toputech/ALONE-MD-V1/fork)  

<br>

2. 👇 Get Session ID Here for wa.connection
[![Get Session ID Here](https://img.shields.io/static/v1?label=Session%20ID&message=Generate&color=FF4500&style=for-the-badge&logo=firefox&logoColor=orange)](https://alone-md-nkds.onrender.com/pair) 


<br>

3.👇 Create Account on Heroku  
[![Create Account on Heroku](https://img.shields.io/static/v1?label=Create%20Account&message=Heroku&color=430098&style=for-the-badge&logo=heroku&logoColor=red)](https://heroku.com)  

<br>

4.👇 Deploy to Heroku If your have account
[![Deploy to Heroku](https://img.shields.io/static/v1?label=Deploy%20to&message=Heroku&color=430098&style=for-the-badge&logo=heroku&logoColor=white)](https://dashboard.heroku.com/new?template=https://github.com/Toputech/turn-meh)  


   © Toputech 


   
## Supported Versions Node Versions to run this bot

Please Use Node Version Higher to Get The Best Performance.

| Version | Supported          |
| ------- | ------------------ |
| 14.x   | :x: |
| 16.x   | ❗                |
| 18.x   | :white_check_mark: |
| 20.x   | ✅                |

## Support 
<a href="https://whatsapp.com/channel/0029VaeRrcnADTOKzivM0S1r" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Whatsapp Support Channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
</p>


HOW TO REACH THE OWNER? 
 
   
   <a href="https://wa.me/c/+255673750170">
    <img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>&nbsp;&nbsp;
   <a

    ## Ask any thing
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>



## Makesure you follow my channel for latest updates 
 [`WA CHANNEL`](https://whatsapp.com/channel/0029VaeRrcnADTOKzivM0S1r)



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
   
   
## Thankyou for choosing ALONE MD bot 


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## Contributions


Contributions to *ALONE-MD* are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

# Security Notice
Alone Md is safe for your WhatsApp and heroku



## powered by TOPU MD



The *ALONE-MD* is released under the [MIT License](https://opensource.org/licenses/MIT).

