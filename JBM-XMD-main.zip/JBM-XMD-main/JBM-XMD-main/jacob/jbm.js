// Bwm xmd dark side by Ibrahim Adams
const bwmxmd3 = "hey beb";

// Xmd1
module.exports = {
    bwmxmd3
};
